create table 회원(
    회원아이디 varchar(20) not null primary key,
    비밀번호 varchar(20) not null,
    이름 varchar(20) not null,
    나이 int,
    직업 varchar(20),
    등급 varchar(20) not null, 
    적립금 int not null
);

-- 적립금 컬럼의 기본값 설정(기본값 0으로 수정)
ALTER TABLE 회원
MODIFY 적립금 DEFAULT (0);

ALTER TABLE 회원
ADD CONSTRAINT CHK_회원_등급 CHECK (등급 IN ('SILVER', 'GOLD', 'VIP'));

create table 상품(
    상품번호 int not null primary key,
    상품명 varchar(30) not null, 
    재고량 int not null,
    단가 int not null,
    제조업체명 varchar(30) not null,
    공급일자 date not null,
    공급량 int not null
);

ALTER TABLE 상품
ADD CONSTRAINT FK_상품_제조업체
FOREIGN KEY (제조업체명) REFERENCES 제조업체(제조업체);

-- 상품 테이블에 제약조건 추가
ALTER TABLE 상품
ADD CONSTRAINT CHK_상품_재고량 CHECK (재고량 >= 0);

-- 상품 테이블에 제약조건 추가
ALTER TABLE 상품
ADD CONSTRAINT CHK_상품_단가 CHECK (재고량 >= 0);

create table 제조업체(
    제조업체 varchar(20) not null primary key,
    전화번호 varchar(15) not null,
    위치 varchar(20) not null,
    담당자 varchar(20)
);

create table 게시글(
    글번호 int not null primary key,
    글제목 varchar2(30) not null,
    글내용 clob,
    작성일자 date not null,
    회원아이디 varchar2(20), 
    -- 제약조건 지정
    constraint FK_회원아이디
    foreign key (회원아이디)
    references 회원(회원아이디)
);

CREATE TABLE 주문(
    주문번호 INT NOT NULL PRIMARY KEY,
    주문수량 INT NOT NULL,
    배송지 VARCHAR(30),
    주문일자 DATE, 
    회원아이디 VARCHAR(20) NOT NULL,
    상품번호 INT NOT NULL
);

ALTER TABLE 주문
ADD CONSTRAINT FK_주문_회원아이디
FOREIGN KEY (회원아이디) REFERENCES 회원(회원아이디);

ALTER TABLE 주문
ADD CONSTRAINT FK_주문_상품번호
FOREIGN KEY (상품번호) REFERENCES 상품(상품번호);